// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ast

import (
	"fmt"
	"testing"
)

// Make the types prettyprint.
var itemName = map[itemType]string{
	itemError:      "error",
	itemEOF:        "EOF",
	itemLeftParen:  "(",
	itemRightParen: ")",
	itemNil:        "nil",
	itemBool:       "bool",
	itemChar:       "char",
	itemNumber:     "number",
	itemString:     "string",
	itemRawString:  "raw string",
	itemSymbol:     "symbol",
}

func (i itemType) String() string {
	s := itemName[i]
	if s == "" {
		return fmt.Sprintf("item%d", int(i))
	}
	return s
}

type lexTest struct {
	name  string
	input string
	items []item
}

var (
	tEOF      = item{itemEOF, 0, ""}
	tLeft     = item{itemLeftParen, 0, "("}
	tRight    = item{itemRightParen, 0, ")"}
	tQuote    = item{itemString, 0, `"abc \n\t\" "`}
	raw       = "`" + `abc\n\t\" ` + "`"
	tRawQuote = item{itemRawString, 0, raw}
)

var lexTests = []lexTest{
	{"empty", "", []item{tEOF}},
	{"comment", ";12345", []item{tEOF}},
	{"nil", "(nil)", []item{
		tLeft,
		{itemNil, 0, "nil"},
		tRight,
		tEOF,
	}},
	{"bools", "(true false)", []item{
		tLeft,
		{itemBool, 0, "true"},
		{itemBool, 0, "false"},
		tRight,
		tEOF,
	}},
	{"characters", `('a' '\n' '\'' '\\' '\u00FF' '\xFF' '本')`, []item{
		tLeft,
		{itemChar, 0, `'a'`},
		{itemChar, 0, `'\n'`},
		{itemChar, 0, `'\''`},
		{itemChar, 0, `'\\'`},
		{itemChar, 0, `'\u00FF'`},
		{itemChar, 0, `'\xFF'`},
		{itemChar, 0, `'本'`},
		tRight,
		tEOF,
	}},
	{"quote", `("abc \n\t\" ")`, []item{tLeft, tQuote, tRight, tEOF}},
	{"raw quote", "(" + raw + ")", []item{tLeft, tRawQuote, tRight, tEOF}},
	{"numbers", "(1 02 0x6ab 0x8AB 0x14 1e3 +1.2e-4)", []item{
		tLeft,
		{itemNumber, 0, "1"},
		{itemNumber, 0, "02"},
		{itemNumber, 0, "0x6ab"},
		{itemNumber, 0, "0x8AB"},
		{itemNumber, 0, "0x14"},
		{itemNumber, 0, "1e3"},
		{itemNumber, 0, "+1.2e-4"},
		tRight,
		tEOF,
	}},
	{"symbols", "(x y z)", []item{
		tLeft,
		{itemSymbol, 0, "x"},
		{itemSymbol, 0, "y"},
		{itemSymbol, 0, "z"},
		tRight,
		tEOF,
	}},
	// errors
	{"unclosed", "(", []item{
		tLeft,
		{itemError, 0, "unclosed paren"},
	}},
	{"unmatched", "())", []item{
		tLeft,
		tRight,
		{itemError, 0, "unmatched right paren"},
	}},
	{"badchar", "(\x01)", []item{
		tLeft,
		{itemError, 0, "unknown character: U+0001"},
	}},
	{"unclosed char", "('\n)", []item{
		tLeft,
		{itemError, 0, "unclosed character"},
	}},
	{"unclosed quote", "(\"\n\")", []item{
		tLeft,
		{itemError, 0, "unclosed quoted string"},
	}},
	{"unclosed raw quote", "(`xx)", []item{
		tLeft,
		{itemError, 0, "unclosed raw quoted string"},
	}},

	{"bad char", "('\\n'a)", []item{
		tLeft,
		{itemError, 0, `bad char syntax: '\n'a`},
	}},
	{"bad quote", "(\"\\n\"a)", []item{
		tLeft,
		{itemError, 0, `bad quoted string syntax: "\n"a`},
	}},
	{"bad raw quote", "(`xx`a)", []item{
		tLeft,
		{itemError, 0, "bad raw quoted string syntax: `xx`a"},
	}},
	{"bad number", "(3k)", []item{
		tLeft,
		{itemError, 0, `bad number syntax: "3k"`},
	}},
}

// collect gathers the emitted items into a slice.
func collect(t *lexTest) (items []item) {
	l := lex(t.input)
	for {
		item := l.nextItem()
		items = append(items, item)
		if item.typ == itemEOF || item.typ == itemError {
			break
		}
	}
	return
}

func equal(i1, i2 []item, checkPos bool) bool {
	if len(i1) != len(i2) {
		return false
	}
	for k := range i1 {
		if i1[k].typ != i2[k].typ {
			return false
		}
		if i1[k].val != i2[k].val {
			return false
		}
		if checkPos && i1[k].pos != i2[k].pos {
			return false
		}
	}
	return true
}

func TestLex(t *testing.T) {
	for _, test := range lexTests {
		items := collect(&test)
		if !equal(items, test.items, false) {
			t.Errorf("%s: \ngot\n\t%+v\nexpected\n\t%v", test.name, items, test.items)
		}
	}
}

var lexPosTests = []lexTest{
	{"empty", "", []item{tEOF}},
	{"nil", "(nil)", []item{
		{itemLeftParen, 0, "("},
		{itemNil, 1, "nil"},
		{itemRightParen, 4, ")"},
		{itemEOF, 5, ""},
	}},
	{"bools", "(true false)", []item{
		{itemLeftParen, 0, "("},
		{itemBool, 1, "true"},
		{itemBool, 6, "false"},
		{itemRightParen, 11, ")"},
		{itemEOF, 12, ""},
	}},
}

// The other tests don't check position, to make the test cases easier to construct.
// This one does.
func TestPos(t *testing.T) {
	for _, test := range lexPosTests {
		items := collect(&test)
		if !equal(items, test.items, true) {
			t.Errorf("%s: \ngot\n\t%v\nexpected\n\t%v", test.name, items, test.items)
			if len(items) == len(test.items) {
				// Detailed print; avoid item.String() to expose the position value.
				for i := range items {
					if !equal(items[i:i+1], test.items[i:i+1], true) {
						i1 := items[i]
						i2 := test.items[i]
						t.Errorf("\t#%d: got {%v %d %q} expected  {%v %d %q}", i, i1.typ, i1.pos, i1.val, i2.typ, i2.pos, i2.val)
					}
				}
			}
		}
	}
}
