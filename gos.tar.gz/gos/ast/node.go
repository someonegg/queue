// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ast

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
)

const (
	rootDelim = "\n"
	listDelim = " "
)

// NodeType identifies the type of a ast tree node.
type NodeType int

const (
	NodeRoot       NodeType = iota // The root node.
	NodeList                       // A list of Nodes.
	NodeNil                        // An untyped nil constant.
	NodeBool                       // A boolean constant.
	NodeNumber                     // A numerical constant.
	NodeString                     // A string constant.
	NodeSymbol                     // A symbol.
	NodeFieldChain                 // A field chain.
)

// Pos represents a byte position in the input code.
type Pos int

// PosInfo represents a textual representation position.
type PosInfo struct {
	Name   string
	Line   int
	Column int
}

func (info *PosInfo) String() string {
	name := "anonymous"
	if info.Name != "" {
		name = info.Name
	}
	return fmt.Sprintf("%s:%d:%d:", name, info.Line, info.Column)
}

// A Node is an element in the ast tree.
type Node interface {
	Type() NodeType
	Pos() Pos
	PosInfo() *PosInfo
	String() string
}

// The _Node struct implements the Node interface.
type _Node struct {
	typ NodeType
	pos Pos
	tr  *Tree
}

func (n *_Node) Type() NodeType {
	return n.typ
}

func (n *_Node) Pos() Pos {
	return n.pos
}

func (n *_Node) PosInfo() *PosInfo {
	pinfo := &PosInfo{}
	pinfo.Name = n.tr.Name
	code := n.tr.code[:n.pos]
	pinfo.Line = 1 + strings.Count(code, "\n")
	if i := strings.LastIndex(code, "\n"); i >= 0 {
		pinfo.Column = int(n.pos) - i
	} else {
		pinfo.Column = len(code) + 1
	}
	return pinfo
}

// RootNode is the root of a ast tree.
type RootNode struct {
	_Node
	Childs []Node // The child nodes.
}

func (t *Tree) newRoot() *RootNode {
	return &RootNode{
		_Node: _Node{NodeRoot, 0, t},
	}
}

func (r *RootNode) append(n Node) {
	r.Childs = append(r.Childs, n)
}

func (r *RootNode) String() string {
	b := new(bytes.Buffer)
	first := true
	for _, n := range r.Childs {
		if first {
			first = false
		} else {
			fmt.Fprint(b, rootDelim)
		}
		fmt.Fprint(b, n)
	}
	return b.String()
}

// ListNode holds a sequence of nodes.
type ListNode struct {
	_Node
	Nodes []Node // The element nodes.
}

func (t *Tree) newList(pos Pos) *ListNode {
	return &ListNode{
		_Node: _Node{NodeList, pos, t},
	}
}

func (l *ListNode) append(n Node) {
	l.Nodes = append(l.Nodes, n)
}

func (l *ListNode) String() string {
	if len(l.Nodes) == 0 {
		return ""
	}
	b := new(bytes.Buffer)
	fmt.Fprintf(b, "%c", leftParen)
	first := true
	for _, n := range l.Nodes {
		if first {
			first = false
		} else {
			fmt.Fprint(b, listDelim)
		}
		fmt.Fprint(b, n)
	}
	fmt.Fprintf(b, "%c", rightParen)
	return b.String()
}

// NilNode holds the special identifier 'nil' representing
// an untyped nil constant.
type NilNode struct {
	_Node
}

func (t *Tree) newNil(pos Pos) *NilNode {
	return &NilNode{
		_Node: _Node{NodeNil, pos, t},
	}
}

func (n *NilNode) String() string {
	return "nil"
}

// BoolNode holds a boolean constant.
type BoolNode struct {
	_Node
	True bool // The value of the boolean constant.
}

func (t *Tree) newBool(pos Pos, b bool) *BoolNode {
	return &BoolNode{
		_Node: _Node{NodeBool, pos, t},
		True:  b,
	}
}

func (b *BoolNode) String() string {
	if b.True {
		return "true"
	}
	return "false"
}

// NumberNode holds a number: integer, float (no complex).
// The value is parsed and stored under all the types that
// can represent the value.
type NumberNode struct {
	_Node
	IsInt   bool    // Number has an integral value.
	IsFloat bool    // Number has a floating-point value.
	Int64   int64   // The signed integer value.
	Float64 float64 // The floating-point value.
	Orig    string  // The original textual representation from the input.
}

func (t *Tree) newCharNum(pos Pos, orig string) (*NumberNode, error) {
	n := &NumberNode{
		_Node: _Node{NodeNumber, pos, t},
		Orig:  orig,
	}

	rune, _, tail, err := strconv.UnquoteChar(orig[1:], orig[0])
	if err != nil {
		return nil, err
	}
	if tail != "'" {
		return nil, fmt.Errorf("malformed character: %s", orig)
	}
	n.Int64 = int64(rune)
	n.IsInt = true
	n.Float64 = float64(rune)
	n.IsFloat = true
	return n, nil
}

func (t *Tree) newNumber(pos Pos, orig string) (*NumberNode, error) {
	n := &NumberNode{
		_Node: _Node{NodeNumber, pos, t},
		Orig:  orig,
	}

	i, err := strconv.ParseInt(orig, 0, 64)
	if err == nil {
		n.IsInt = true
		n.Int64 = i
	}

	if n.IsInt {
		n.IsFloat = true
		n.Float64 = float64(n.Int64)
	} else {
		f, err := strconv.ParseFloat(orig, 64)
		if err == nil {
			n.IsFloat = true
			n.Float64 = f
			// If a floating-point extraction succeeded, extract the
			// int if needed.
			if !n.IsInt && float64(int64(f)) == f {
				n.IsInt = true
				n.Int64 = int64(f)
			}
		}
	}

	if !n.IsInt && !n.IsFloat {
		return nil, fmt.Errorf("bad number syntax: %q", orig)
	}
	return n, nil
}

func (n *NumberNode) String() string {
	return n.Orig
}

// StringNode holds a string constant. The value has been "unquoted".
type StringNode struct {
	_Node
	Orig string // The original string, with quotes.
	Str  string // The string, after quote processing.
}

func (t *Tree) newString(pos Pos, orig, str string) *StringNode {
	return &StringNode{
		_Node: _Node{NodeString, pos, t},
		Orig:  orig,
		Str:   str,
	}
}

func (s *StringNode) String() string {
	return s.Orig
}

// SymbolNode holds a symbol info.
type SymbolNode struct {
	_Node
	Name string // The name of the symbol.
}

func (t *Tree) newSymbol(pos Pos, name string) *SymbolNode {
	return &SymbolNode{
		_Node: _Node{NodeSymbol, pos, t},
		Name:  name,
	}
}

func (s *SymbolNode) String() string {
	return s.Name
}

// FieldChainNode holds a field chain info.
type FieldChainNode struct {
	_Node
	Orig  string   // The original field chain string.
	Name  string   // The object name.
	Ident []string // The field name slice.
}

func (t *Tree) newFieldChain(pos Pos, orig string) (*FieldChainNode, error) {
	f := &FieldChainNode{
		_Node: _Node{NodeFieldChain, pos, t},
		Orig:  orig,
	}

	f.Ident = strings.Split(orig, dotS)
	if len(f.Ident) < 2 {
		return nil, fmt.Errorf("bad field chain syntax: %q", orig)
	}
	for i := 0; i < len(f.Ident); i++ {
		if len(f.Ident[i]) == 0 {
			return nil, fmt.Errorf("bad field chain syntax: %q", orig)
		}
	}

	f.Name = f.Ident[0]
	f.Ident = f.Ident[1:]
	return f, nil
}

func (f *FieldChainNode) String() string {
	return f.Orig
}
