// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package ast builds ast tree for gos codes.
package ast

import (
	"fmt"
	"strconv"
	"strings"
)

// Tree is the ast of a single code.
type Tree struct {
	Name string    // name of the code.
	Root *RootNode // root of the tree.
	code string
	// Parsing only; cleared after parse.
	lex *lexer
}

// next returns the next token.
func (t *Tree) next() item {
	return t.lex.nextItem()
}

// errorf formats the error and terminates processing.
func (t *Tree) errorf(format string, args ...interface{}) {
	t.Root = nil
	format = fmt.Sprintf("%s:%d: %s", t.Name, t.lex.lineNumber(), format)
	panic(fmt.Errorf(format, args...))
}

// error terminates processing.
func (t *Tree) error(err error) {
	t.errorf("%s", err)
}

// unexpected complains about the token and terminates processing.
func (t *Tree) unexpected(token item, context string) {
	t.errorf("unexpected %s in %s", token, context)
}

func Parse(name, code string) (tree *Tree, err error) {
	defer errRecover(&err)
	t := &Tree{Name: name, code: code}
	t.startParse(lex(t.code))
	defer t.stopParse()
	t.parse()
	return t, nil
}

// errRecover is the handler that turns panics into returns from the top
// level of Parse.
func errRecover(errp *error) {
	e := recover()
	if e != nil {
		switch err := e.(type) {
		case error:
			*errp = err
		default:
			panic(e)
		}
	}
}

// startParse initializes the parser, using the lexer.
func (t *Tree) startParse(lex *lexer) {
	t.Root = nil
	t.lex = lex
}

// stopParse terminates parsing.
func (t *Tree) stopParse() {
	t.lex = nil
}

func (t *Tree) parse() {
	const context = "root context"
	t.Root = t.newRoot()
	for {
		switch token := t.next(); token.typ {
		case itemEOF:
			return
		case itemError:
			t.errorf("%s", token.val)
		case itemLeftParen:
			node := t.parseList(token.pos)
			t.Root.append(node)
		default:
			t.unexpected(token, context)
		}
	}
}

func (t *Tree) parseList(pos Pos) *ListNode {
	const context = "list context"
	list := t.newList(pos)
	for {
		switch token := t.next(); token.typ {
		case itemRightParen:
			return list
		case itemError:
			t.errorf("%s", token.val)
		case itemLeftParen:
			node := t.parseList(token.pos)
			list.append(node)
		case itemNil, itemBool, itemChar, itemNumber, itemString, itemRawString:
			node := t.parseConst(token)
			list.append(node)
		case itemSymbol:
			node := t.parseSymbol(token)
			list.append(node)
		default:
			t.unexpected(token, context)
		}
	}
}

func (t *Tree) parseConst(token item) Node {
	const context = "const context"
	switch token.typ {
	case itemNil:
		return t.newNil(token.pos)
	case itemBool:
		return t.newBool(token.pos, token.val == "true")
	case itemChar:
		num, err := t.newCharNum(token.pos, token.val)
		if err != nil {
			t.error(err)
		}
		return num
	case itemNumber:
		num, err := t.newNumber(token.pos, token.val)
		if err != nil {
			t.error(err)
		}
		return num
	case itemString, itemRawString:
		s, err := strconv.Unquote(token.val)
		if err != nil {
			t.error(err)
		}
		return t.newString(token.pos, token.val, s)
	default:
		t.unexpected(token, context)
		return nil
	}
}

func (t *Tree) parseSymbol(token item) Node {
	if strings.IndexByte(token.val, dot) != -1 {
		node, err := t.newFieldChain(token.pos, token.val)
		if err != nil {
			t.error(err)
		}
		return node
	}
	return t.newSymbol(token.pos, token.val)
}
