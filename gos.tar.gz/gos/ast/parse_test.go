// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ast

import (
	"flag"
	"fmt"
	"strings"
	"testing"
)

var debug = flag.Bool("debug", false, "show the errors produced by the main tests")

type numberTest struct {
	text    string
	isInt   bool
	isFloat bool
	int64
	float64
}

var numberTests = []numberTest{
	// basics
	{"0", true, true, 0, 0},
	{"-0", true, true, 0, 0},
	{"73", true, true, 73, 73},
	{"073", true, true, 073, 073},
	{"0x73", true, true, 0x73, 0x73},
	{"-73", true, true, -73, -73},
	{"+73", true, true, 73, 73},
	{"100", true, true, 100, 100},
	{"1e9", true, true, 1e9, 1e9},
	{"-1e9", true, true, -1e9, -1e9},
	{"-1.2", false, true, 0, -1.2},
	{"1e19", false, true, 0, 1e19},
	{"-1e19", false, true, 0, -1e19},
	// funny bases
	{"0123", true, true, 0123, 0123},
	{"-0x0", true, true, 0, 0},
	{"0xdeadbeef", true, true, 0xdeadbeef, 0xdeadbeef},
	// character constants
	{`'a'`, true, true, 'a', 'a'},
	{`'\n'`, true, true, '\n', '\n'},
	{`'\\'`, true, true, '\\', '\\'},
	{`'\''`, true, true, '\'', '\''},
	{`'\xFF'`, true, true, 0xFF, 0xFF},
	{`'パ'`, true, true, 0x30d1, 0x30d1},
	{`'\u30d1'`, true, true, 0x30d1, 0x30d1},
	{`'\U000030d1'`, true, true, 0x30d1, 0x30d1},
	// some broken syntax
	{text: "+-2"},
	{text: "0x123."},
	{text: "1e."},
	{text: "0xi."},
	{text: "1+2."},
	{text: "'x"},
	{text: "'xx'"},
	{"0xef", true, true, 0xef, 0xef},
}

func TestNumberParse(t *testing.T) {
	for _, test := range numberTests {
		var tree *Tree
		n, err := tree.newNumber(0, test.text)
		if test.text[0] == '\'' {
			n, err = tree.newCharNum(0, test.text)
		}
		ok := test.isInt || test.isFloat
		if ok && err != nil {
			t.Errorf("unexpected error for %q: %s", test.text, err)
			continue
		}
		if !ok && err == nil {
			t.Errorf("expected error for %q", test.text)
			continue
		}
		if !ok {
			if *debug {
				fmt.Printf("%s\n\t%s\n", test.text, err)
			}
			continue
		}
		if test.isInt {
			if !n.IsInt {
				t.Errorf("expected integer for %q", test.text)
			}
			if n.Int64 != test.int64 {
				t.Errorf("int64 for %q should be %d Is %d", test.text, test.int64, n.Int64)
			}
		} else if n.IsInt {
			t.Errorf("did not expect integer for %q", test.text)
		}
		if test.isFloat {
			if !n.IsFloat {
				t.Errorf("expected float for %q", test.text)
			}
			if n.Float64 != test.float64 {
				t.Errorf("float64 for %q should be %g Is %g", test.text, test.float64, n.Float64)
			}
		} else if n.IsFloat {
			t.Errorf("did not expect float for %q", test.text)
		}
	}
}

type parseTest struct {
	name   string
	input  string
	ok     bool
	result string // what the user would see in an error message.
}

const (
	noError  = true
	hasError = false
)

var parseTests = []parseTest{
	{"empty", "", noError,
		``},
	{"comment", ";comm \t ent\r\n", noError,
		``},
	{"spaces", " \t\n\r\n", noError,
		``},
	{"list", `(x "y " 'z')`, noError,
		`(x "y " 'z')`},
	{"lists", "(x y z) (a b c d) \r\n\n (l m n)\n\r\r\n", noError,
		"(x y z)\n(a b c d)\n(l m n)"},
	{"nestlists", "(  ( 1 2 3) (y (5 6 8)) z)", noError,
		"((1 2 3) (y (5 6 8)) z)"},
	// Errors.
	{"unclosed", "(a b c", hasError, ""},
	{"unmatched", "(a ) )", hasError, ""},
	{"unexpected", "a", hasError, ""},
}

func TestParse(t *testing.T) {
	for _, test := range parseTests {
		tree, err := Parse(test.name, test.input)
		switch {
		case err == nil && !test.ok:
			t.Errorf("%q: expected error; got none", test.name)
			continue
		case err != nil && test.ok:
			t.Errorf("%q: unexpected error: %v", test.name, err)
			continue
		case err != nil && !test.ok:
			// expected error, got one
			if *debug {
				fmt.Printf("%s: %s\n\t%s\n", test.name, test.input, err)
			}
			continue
		}
		result := tree.Root.String()
		if result != test.result {
			t.Errorf("%s=(%q):\ngot\n\t%v\nexpected\n\t%v", test.name, test.input, result, test.result)
		}
	}
}

// All failures, and the result is a string that must appear in the error message.
var errorTests = []parseTest{
	{"unclosed",
		"(a b \nc",
		hasError, "unclosed paren"},
	{"unmatched",
		"(a ) )",
		hasError, "unmatched right paren"},
	{"unexpected",
		"a",
		hasError, "unexpected"},
	{"bad syntax",
		"(a#)",
		hasError, `bad symbol syntax`},
	{"charconst",
		"('a)",
		hasError, `unclosed character`},
	{"stringconst",
		`("a)`,
		hasError, `unclosed quoted string`},
	{"rawstringconst",
		"(`a)",
		hasError, `unclosed raw quoted string`},
	{"number",
		"(0xi)",
		hasError, `bad number syntax`},
}

func TestErrors(t *testing.T) {
	for _, test := range errorTests {
		_, err := Parse(test.name, test.input)
		if err == nil {
			t.Errorf("%q: expected error", test.name)
			continue
		}
		if !strings.Contains(err.Error(), test.result) {
			t.Errorf("%q: error %q does not contain %q", test.name, err, test.result)
		}
	}
}
