// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gos

var rootVM *VM

func init() {
	rootVM = &VM{Objs: make(map[string]interface{})}
	for _, obj := range builtins {
		rootVM.Objs[obj.name] = obj.value
	}
}

var builtins = []struct {
	name  string
	value interface{}
}{}
