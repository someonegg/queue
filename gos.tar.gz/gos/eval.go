// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gos

import (
	"errors"
	"fmt"
	"jtwsm.net/gocode/gos/ast"
	"reflect"
)

var (
	errInvalidFunc     = errors.New("must be a non-nil func")
	errUnsupportedFunc = errors.New("unsupported func type")
	errArgsNumber      = errors.New("wrong number of args")

	errInvalidObj = errors.New("must be a non-nil obj")
)

// state represents the state of an evaluation.
// It's not part of the vm so that multiple evaluations
// can execute in parallel.
type state struct {
	vm   *VM
	objs map[string]interface{} // local objects.

	inDefer bool
	defers  []ast.Node

	curNode ast.Node // current node, for errors.
	lastErr error    // error of last func
}

func (s *state) get(name string) interface{} {
	if obj, ok := s.objs[name]; ok {
		return obj
	}
	return s.vm.Get(name)
}

func (s *state) set(name string, obj interface{}) {
	if s.objs == nil {
		s.objs = make(map[string]interface{})
	}
	s.objs[name] = obj
}

func (s *state) del(name string) {
	if s.objs != nil {
		delete(s.objs, name)
	}
}

// CtxErr contains an error and its associated context.
type CtxErr struct {
	Err error
	Pos *ast.PosInfo
}

func (e CtxErr) Error() string {
	return fmt.Sprintf("%v %v", e.Pos, e.Err)
}

func errAt(err error, node ast.Node) error {
	if _, ok := err.(CtxErr); ok {
		return err
	}
	if _, ok := err.(*CtxErr); ok {
		return err
	}
	return CtxErr{err, node.PosInfo()}
}

func (s *state) error(err error) {
	if s.curNode != nil {
		err = errAt(err, s.curNode)
	}
	panic(err)
}

func (s *state) errorf(format string, args ...interface{}) {
	s.error(fmt.Errorf(format, args...))
}

type interrupt struct {
	retObj interface{}
}

func (s *state) interrupt(retObj interface{}) {
	panic(interrupt{retObj})
}

func (s *state) regDefer(node ast.Node) {
	if s.inDefer {
		return
	}
	s.defers = append(s.defers, node)
}

func (s *state) Eval(node ast.Node) (obj interface{}, err error) {
	obj, err = s.peval(node)
	s.doDefer()
	return obj, err
}

func (s *state) doDefer() {
	s.inDefer = true
	defer func() { s.inDefer = false }()
	defers := s.defers
	s.defers = nil
	for i := len(defers); i > 0; i-- {
		s.peval(defers[i-1])
	}
}

// protected eval.
func (s *state) peval(node ast.Node) (obj interface{}, err error) {
	defer protect(&obj, &err)
	obj = s.eval(node)
	return
}

// protect is the handler that turns panics into returns from
// the protected eval.
func protect(objp *interface{}, errp *error) {
	e := recover()
	if e != nil {
		switch o := e.(type) {
		case interrupt:
			*objp = o.retObj
		case *interrupt:
			*objp = o.retObj
		case error:
			*errp = o
		default:
			panic(e)
		}
	}
}

func (s *state) eval(node ast.Node) (obj interface{}) {
	older := s.at(node)
	switch node := node.(type) {
	case *ast.NilNode:
		obj = nil
	case *ast.BoolNode:
		obj = node.True
	case *ast.NumberNode:
		if node.IsInt {
			obj = node.Int64
		} else {
			obj = node.Float64
		}
	case *ast.StringNode:
		obj = node.Str
	case *ast.SymbolNode:
		obj = s.get(node.Name)
	case *ast.FieldChainNode:
		obj = s.evalFieldChain(node)
	case *ast.ListNode:
		obj = s.evalList(node)
	case *ast.RootNode:
		for _, node := range node.Childs {
			obj = s.eval(node)
		}
	default:
		panic("unreachable code")
	}
	s.at(older)
	return
}

func (s *state) at(node ast.Node) ast.Node {
	older := s.curNode
	s.curNode = node
	return older
}

func (s *state) evalFieldChain(node *ast.FieldChainNode) interface{} {
	obj := s.get(node.Name)
	if obj == nil {
		s.error(errInvalidObj)
	}
	objVal := reflect.ValueOf(obj)
	ident := node.Ident
	for i := 0; i < len(ident); i++ {
		objVal = s.evalFieldV(objVal, ident[i])
	}
	return objVal.Interface()
}

func (s *state) evalFieldV(objVal reflect.Value, fieldName string) reflect.Value {
	if !objVal.IsValid() {
		s.errorf("invalid obj evaluating .%s", fieldName)
	}
	objTyp := objVal.Type()
	objVal, _ = indirect(objVal)
	// Unless it's an interface, need to get to a value of type *T to guarantee
	// we see all methods of T and *T.
	ptr := objVal
	if ptr.Kind() != reflect.Interface && ptr.CanAddr() {
		ptr = ptr.Addr()
	}
	if method := ptr.MethodByName(fieldName); method.IsValid() {
		return method
	}
	// It's not a method; must be a field of a struct or an element of a map. The obj must not be nil.
	objVal, isNil := indirect(objVal)
	if isNil {
		s.errorf("nil pointer evaluating %s.%s", objTyp, fieldName)
	}
	switch objVal.Kind() {
	case reflect.Struct:
		tField, ok := objVal.Type().FieldByName(fieldName)
		if ok {
			field := objVal.FieldByIndex(tField.Index)
			if tField.PkgPath != "" { // field is unexported
				s.errorf("%s is an unexported field of struct type %s", fieldName, objTyp)
			}
			return field
		}
		s.errorf("%s is not a field of struct type %s", fieldName, objTyp)
	case reflect.Map:
		// If it's a map, attempt to use the field name as a key.
		nameVal := reflect.ValueOf(fieldName)
		if nameVal.Type().AssignableTo(objVal.Type().Key()) {
			return objVal.MapIndex(nameVal)
		}
	}
	s.errorf("can't evaluate field %s in type %s", fieldName, objTyp)
	panic("unreachable code")
}

func (s *state) evalList(node *ast.ListNode) interface{} {
	if len(node.Nodes) == 0 {
		return nil
	}
	fn := s.eval(node.Nodes[0])
	return s.evalCall(fn, node.Nodes[1:])
}

func (s *state) evalCall(fn interface{}, args []ast.Node) interface{} {
	if fn == nil {
		s.error(errInvalidFunc)
	}
	// internal
	if fn, ok := fn.(func(*state) interface{}); ok {
		return fn(s)
	}
	if fn, ok := fn.(func(*state, []ast.Node) interface{}); ok {
		return fn(s, args)
	}
	// general
	return s.evalGeneralCall(fn, args)
}

func (s *state) evalGeneralCall(fn interface{}, args []ast.Node) interface{} {
	fnVal := reflect.ValueOf(fn)
	fnTyp := fnVal.Type()

	// func check
	if fnVal.Kind() != reflect.Func {
		s.error(errInvalidFunc)
	}
	switch {
	case fnTyp.NumOut() == 0:
	case fnTyp.NumOut() == 1:
	case fnTyp.NumOut() == 2 && fnTyp.Out(1) == errorType:
	default:
		s.error(errUnsupportedFunc)
	}

	// args check
	numIn := len(args)
	var numFixed int
	if fnTyp.IsVariadic() {
		numFixed = fnTyp.NumIn() - 1
		if numIn < numFixed {
			s.error(errArgsNumber)
		}
	} else {
		numFixed = fnTyp.NumIn()
		if numIn != numFixed {
			s.error(errArgsNumber)
		}
	}

	// Build the arg list.
	argv := make([]reflect.Value, numIn, numIn)
	// Args must be evaluated. Fixed args first.
	i := 0
	for ; i < numFixed && i < len(args); i++ {
		argv[i] = s.evalTypeV(args[i], fnTyp.In(i))
	}
	// Now the ... args.
	if fnTyp.IsVariadic() {
		argType := fnTyp.In(fnTyp.NumIn() - 1).Elem() // Argument is a slice.
		for ; i < len(args); i++ {
			argv[i] = s.evalTypeV(args[i], argType)
		}
	}

	result := fnVal.Call(argv)

	s.lastErr = nil
	if len(result) == 2 {
		if !result[1].IsNil() {
			s.lastErr = result[1].Interface().(error)
		}
		return result[0].Interface()
	}
	if len(result) == 1 {
		return result[0].Interface()
	}
	return nil
}

func (s *state) evalType(node ast.Node, typ reflect.Type) interface{} {
	return s.evalTypeV(node, typ).Interface()
}

func (s *state) evalTypeV(node ast.Node, typ reflect.Type) reflect.Value {
	obj := s.eval(node)
	val := reflect.ValueOf(obj)
	val, err := validateType(val, typ)
	if err != nil {
		s.error(err)
	}
	return val
}
