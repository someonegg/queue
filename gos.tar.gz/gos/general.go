// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gos

import (
	"fmt"
	"reflect"
)

var (
	errorType  = reflect.TypeOf((*error)(nil)).Elem()
	stringType = reflect.TypeOf((*string)(nil)).Elem()

	nilValue = reflect.Value{}
)

// canBeNil reports whether an untyped nil can be assigned to the type. See reflect.Zero.
func canBeNil(typ reflect.Type) bool {
	switch typ.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Ptr, reflect.Slice:
		return true
	}
	return false
}

// isTrue reports whether the value is 'true', in the sense of not the zero of its type,
// and whether the value has a meaningful truth value.
func isTrue(val reflect.Value) (truth, ok bool) {
	if !val.IsValid() {
		// Something like var x interface{}, never set. It's a form of nil.
		return false, true
	}
	switch val.Kind() {
	case reflect.Array, reflect.Map, reflect.Slice, reflect.String:
		truth = val.Len() > 0
	case reflect.Bool:
		truth = val.Bool()
	case reflect.Complex64, reflect.Complex128:
		truth = val.Complex() != 0
	case reflect.Chan, reflect.Func, reflect.Ptr, reflect.Interface:
		truth = !val.IsNil()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		truth = val.Int() != 0
	case reflect.Float32, reflect.Float64:
		truth = val.Float() != 0
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		truth = val.Uint() != 0
	case reflect.Struct:
		truth = true // Struct values are always true.
	default:
		return
	}
	return truth, true
}

// indirect returns the item at the end of indirection, and a bool to indicate if it's nil.
// We indirect through pointers and empty interfaces (only) because
// non-empty interfaces have methods we might need.
func indirect(v reflect.Value) (rv reflect.Value, isNil bool) {
	for ; v.Kind() == reflect.Ptr || v.Kind() == reflect.Interface; v = v.Elem() {
		if v.IsNil() {
			return v, true
		}
		if v.Kind() == reflect.Interface && v.NumMethod() > 0 {
			break
		}
	}
	return v, false
}

func convert(value reflect.Value, typ reflect.Type) (reflect.Value, bool) {
	if value.Type().ConvertibleTo(typ) {
		return value.Convert(typ), true
	} else {
		return value, false
	}
}

// validateType guarantees that the value is valid and assignable to the type.
func validateType(value reflect.Value, typ reflect.Type) (reflect.Value, error) {
	if !value.IsValid() {
		if typ == nil || canBeNil(typ) {
			// An untyped nil interface{}. Accept as a proper nil value.
			return reflect.Zero(typ), nil
		}
		return nilValue, fmt.Errorf("invalid value; expected %s", typ)
	}
	if typ == nil || value.Type().AssignableTo(typ) {
		return value, nil
	}
	if value.Kind() == reflect.Interface && !value.IsNil() {
		value = value.Elem()
		if value.Type().AssignableTo(typ) {
			return value, nil
		}
		// fallthrough
	}
	// Does one dereference or indirection work?
	switch {
	case value.Kind() == reflect.Ptr && value.Type().Elem().AssignableTo(typ):
		value = value.Elem()
		if !value.IsValid() {
			return nilValue, fmt.Errorf("dereference of nil pointer of type %s", typ)
		}
		return value, nil
	case reflect.PtrTo(value.Type()).AssignableTo(typ) && value.CanAddr():
		return value.Addr(), nil
	}

	value, ok := convert(value, typ)
	if ok {
		return value, nil
	}
	return nilValue, fmt.Errorf("wrong type for value; expected %s; got %s", typ, value.Type())
}
