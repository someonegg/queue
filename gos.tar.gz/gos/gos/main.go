// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// gos simple interpreter.
package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"io/ioutil"
	"jtwsm.net/gocode/gos"
	"os"
	"strings"
)

func main() {
	if len(os.Args) > 1 {
		err := runFile()
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
		}
		return
	}
	runInteract()
}

func runFile() error {
	vm := gos.NewVM()
	vm.Set("print", fmt.Print)
	vm.Set("printf", fmt.Printf)

	if strings.HasPrefix(os.Args[1], "-h") {
		return fmt.Errorf("usage: gos [<source file>]")
	}
	f, err := os.Open(os.Args[1])
	if err != nil {
		return err
	}
	defer f.Close()
	data, err := ioutil.ReadAll(f)
	if err != nil {
		return err
	}
	tree, err := gos.Parse(os.Args[1], string(data))
	if err != nil {
		return err
	}

	_, err = vm.Eval(tree.Root)
	return err
}

type Struct struct {
	b byte
	I int
	P *int
}

func runInteract() {
	vm := gos.NewVM()
	vm.Set("print", fmt.Print)
	vm.Set("printf", fmt.Printf)
	vm.Set("t_buf", &bytes.Buffer{})
	vm.Set("t_struct", &Struct{})

	fmt.Println("GOS Interactive Mode")

	t := bufio.NewReader(os.Stdin)
	unclosed := ""
	for {
		if len(unclosed) == 0 {
			fmt.Printf("gos> ")
		} else {
			fmt.Printf("  ->  ")
		}

		line, err := t.ReadString('\n')
		if err == io.EOF {
			break
		}
		if err != nil {
			return
		}

		if len(unclosed) > 0 {
			line = unclosed + line
			unclosed = ""
		} else {
			if line[0] == '=' {
				line = "(print " + line[1:] + ")"
			}
		}

		tree, err := gos.Parse("stdin", line)
		if err != nil {
			if strings.Contains(err.Error(), "unclosed paren") {
				unclosed = line
				continue
			}
			fmt.Println(err)
			continue
		}
		_, err = vm.Eval(tree.Root)
		if err != nil {
			fmt.Println(err)
			continue
		}
	}
	fmt.Println()
}
