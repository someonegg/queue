// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gos

import (
	"jtwsm.net/gocode/gos/ast"
)

// Parse parses a string containing gos code and returns
// the resulting parsed tree.
func Parse(name string, code string) (*ast.Tree, error) {
	return ast.Parse(name, code)
}
