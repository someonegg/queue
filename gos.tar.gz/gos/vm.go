// Copyright 2015 someonegg. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package gos

import (
	"jtwsm.net/gocode/gos/ast"
	"sync"
)

// VM is the environment where gos code runs in.
type VM struct {
	Parent *VM
	Lock   sync.RWMutex
	Objs   map[string]interface{}
}

// NewVM returns a new vm.
func NewVM() *VM {
	return &VM{Parent: rootVM}
}

// Fork returns a new vm that has v as parent.
func (v *VM) Fork() *VM {
	return &VM{Parent: v}
}

func (v *VM) get(name string) (interface{}, bool) {
	v.Lock.RLock()
	defer v.Lock.RUnlock()
	if obj, ok := v.Objs[name]; ok {
		return obj, true
	}
	return nil, false
}

// Get gets object from current vm or parents..., nil if not exist.
func (v *VM) Get(name string) interface{} {
	for v != nil {
		if obj, ok := v.get(name); ok {
			return obj
		}
		v = v.Parent
	}
	return nil
}

// Set sets object to current vm, create if not exist.
func (v *VM) Set(name string, obj interface{}) {
	v.Lock.Lock()
	defer v.Lock.Unlock()
	if v.Objs == nil {
		v.Objs = make(map[string]interface{})
	}
	v.Objs[name] = obj
}

// Eval evaluates node in vm and returns the resulting object.
func (v *VM) Eval(node ast.Node) (interface{}, error) {
	state := &state{vm: v}
	return state.Eval(node)
}
